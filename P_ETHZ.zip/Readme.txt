****** Introduction ******

This is a person dataset with occlusion named P-ETHZ-REID used for occluded person re-identification, selected from [1].

There are two folders in the dataset: <occluded_body_images> and <whole_body_images>.
 
In <occluded_body_images>, there are 546 images of 85 persons with occlusion.
In <whole_body_images>, there are 3351 images of 85 persons without occlusion. 


****** Citation ******

Please cite the following paper if you use the P-ETHZ-REID dataset in your research:

Zhuo, J., Chen, Z., Lai, J., & Wang, G. (2018). Occluded Person Re-identification. arXiv preprint arXiv:1804.02792.

****** Reference ******

[1] A. Ess, B. Leibe, K. Schindler, and L. Van Gool, ��A mobile vision system for robust multi-person tracking," in CVPR, 2008